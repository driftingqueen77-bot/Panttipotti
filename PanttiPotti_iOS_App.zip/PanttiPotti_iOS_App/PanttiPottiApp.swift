import SwiftUI

@main
struct PanttiPottiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
