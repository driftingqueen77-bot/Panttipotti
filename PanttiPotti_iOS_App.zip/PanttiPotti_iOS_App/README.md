# PanttiPotti – iOS SwiftUI App (WKWebView)

Tämä on **valmis lähdekoodipaketti**, jolla ajat PanttiPotti-selainpelin _natiivin_ iOS-apin sisällä offline-tilassa.

## Vaatimukset
- **Xcode 14+** (suositus), iOS **15+**
- Apple ID -> Xcodessa *Signing & Capabilities* (oma kehittäjäprofiili)

## Asennus (5 minuuttia)
1) Avaa Xcode -> *File > New > Project…* -> _App_  
   - Product Name: **PanttiPotti**
   - Interface: **SwiftUI**
   - Language: **Swift**
2) Luo projekti. Poista Xcoden luoma `ContentView.swift` ja lisää **nämä tiedostot** projektiin:
   - `PanttiPottiApp.swift`
   - `ContentView.swift`
   - `WebView.swift`
   - `panttipotti_ultra.html`
   (Muista ruksata *Copy items if needed* ja *Add to targets: PanttiPotti*)
3) Aja projekti iPhone-simulaattorilla tai omalla laitteella.
4) Peli avautuu koko ruutuun ja toimii täysin offline.

## Huomioita
- HTML: `panttipotti_ultra.html` on kevyt versio (ei ääniä/haptics), tehty yhteensopivaksi iPhonen Safarin kanssa.
- Jos haluat käyttää toista HTML-versiota (esim. drag & drop + äänet), korvaa tiedosto projektissa.
- WKWebView lataa paikallisen tiedoston: ei tarvetta verkkoyhteydelle.

## Jatkokehitys
- Lisää `AppIcon.appiconset` Xcassets:iin (valinnainen).
- Lisää `GameCenter`/analytiikka myöhemmin.
- Halutessasi voit paketoida tämän myöhemmin TestFlightiin.

Onnea julkaisuun! 🚀
