import SwiftUI
import WebKit

struct ContentView: View {
    var body: some View {
        WebView(htmlFileName: "panttipotti_ultra", htmlFileExtension: "html")
            .ignoresSafeArea()
    }
}
