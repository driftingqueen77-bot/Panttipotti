import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let htmlFileName: String
    let htmlFileExtension: String

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.bounces = true

        if let url = Bundle.main.url(forResource: htmlFileName, withExtension: htmlFileExtension) {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        } else {
            let html = "<html><body><h3>HTML not found</h3><p>Add panttipotti_ultra.html to the app bundle.</p></body></html>"
            webView.loadHTMLString(html, baseURL: nil)
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
